#include "Point.h"
#include "Circle.h"
#include <iostream>
int main() {
Circle a = Circle(3, Point(1, 2, 'a'), 'a');
Circle b;
std::cout << a.isLarger(b) << std::endl;
Circle c = a;
c.shift(Point(2, 2, '2'));
return 0;
}
