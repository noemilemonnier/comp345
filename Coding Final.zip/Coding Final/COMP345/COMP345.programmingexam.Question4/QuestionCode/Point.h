#pragma once
#include <iostream>
using namespace std;

class Point {
public:
Point(): x_(0), y_(0), name_('0') { cout << "Point(" << name_ << ")" << endl; }
Point(const int x, const int y, const char name): x_(x), y_(y), name_(name)
{ cout << "Point(int,int," << name << ")" << endl; }
int x() {return x_;}
int y() {return y_;}
char name() {return name_;}
private:
int x_, y_;
char name_;
};
