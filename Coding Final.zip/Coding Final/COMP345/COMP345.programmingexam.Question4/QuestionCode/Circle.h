#include "Point.h"
#include <iostream>
using namespace std;

class Circle {
public:
  Circle(): radius_(1), name_('0') {
    center_ = new Point();
    cout << "Circle(" << name_ << ")" << endl;
  }


  Circle(const int radius, Point center, const char name): radius_(radius), name_(name){
  center_ = new Point(center);
  cout << "Circle(int,Point," << name << ")" << endl;
  }


~Circle() {delete center_; cout << "~Circle(" << name_ << ")" << endl; }

  int radius() { return radius_; }
  char name() { return name_;}
  bool isLarger(Circle other);
  void shift(Point newCenter);
  Circle& operator=(Circle& a);


  int    radius_;
  Point* center_;
  char   name_; 
};
