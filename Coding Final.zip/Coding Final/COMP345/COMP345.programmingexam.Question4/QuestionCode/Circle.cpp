#include "Circle.h"
bool Circle::isLarger(Circle other) {
  return radius_ > other.radius();
}
void Circle::shift(Point p) {
  delete center_;
  center_ = new Point(p.x(), p.y(), 's');
}
