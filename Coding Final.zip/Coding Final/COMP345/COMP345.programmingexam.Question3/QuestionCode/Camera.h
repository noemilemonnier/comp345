// Camera.h 

#pragma once
#include "Gunslinger.h"
#include "Observer.h"

class Camera: public Observer { 
  public:
	Camera();
	Camera(GunSlinger* newGunSligner);
	void showClip();
	void Update();
  private:
	GunSlinger* shooter;
};