// Gunslinger.h

#pragma once
#include <string>
#include "Subject.h"
#include"Observer.h"
using namespace std;

enum State { duel, blinking, shooting, dead };

class GunSlinger : public Subject{
  public:
	GunSlinger();
	GunSlinger(string newName);
	State getState();
	void setState(State newState);
	string getName();
	void setTarget(GunSlinger* newTarget);
	void shot();
	void shoot();
	void blink();
	void Attach(Observer* o);
	void Detach(Observer* o);
	void Notify();

  private:
	GunSlinger* target;
	State state;
	string name;
};
