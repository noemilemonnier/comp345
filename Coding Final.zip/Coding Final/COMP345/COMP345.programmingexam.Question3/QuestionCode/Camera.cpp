// Camera.cpp

#include "Camera.h"
#include "Gunslinger.h"
#include <iostream>
using namespace std;

Camera::Camera(){};

Camera::Camera(GunSlinger* newGunSligner){
	shooter = newGunSligner;
};

void Camera::showClip(){
	switch (shooter->getState()) {
	case duel:
		cout << shooter->getName() << ": stands, tickly fingers" << endl;
		break;
	case blinking:
		cout << shooter->getName() << ": sweating, blinks" << endl;
		break;
	case dead:
		cout << shooter->getName() << ": knees bend, falls dead" << endl;
		break;
	case shooting:
		cout << shooter->getName() << ": lightning-fast shot" << endl;
		break;
	}
};

void Camera::Update() 
{
	showClip();
}
