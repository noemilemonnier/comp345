// Gunslinger.cpp

#include "Gunslinger.h"
#include <string>
using namespace std;

void GunSlinger::Notify()
{
	list<Observer*>::iterator it;
	for (it = _observers->begin(); it != _observers->end(); it++)
	{
		Observer *obs;
		obs = *it;
		obs->Update();
	}
}


GunSlinger::GunSlinger(){};

GunSlinger::GunSlinger(string newName){
	name = newName;
}

State GunSlinger::getState() {
	return state;
}

string GunSlinger::getName() {
	return name;
}

void GunSlinger::setState(State newState){
	state = newState;
}

void GunSlinger::shot(){
	setState(dead);
	Notify();
}

void GunSlinger::shoot(){
	setState(shooting);
	Notify();
	target->shot();
}

void GunSlinger::blink(){
	setState(blinking);
	Notify();
}

void GunSlinger::setTarget(GunSlinger* newTarget){
	target = newTarget;
	setState(duel);
	Notify();
}

void GunSlinger::Attach(Observer* o) 
{
	_observers->push_back(o);
}

void GunSlinger::Detach(Observer* o) {}

