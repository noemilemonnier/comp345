// DuelDriver.cpp

#include "Gunslinger.h"                                         
#include "Camera.h"
#include <iostream>
using namespace std;

int main(){
	GunSlinger* JohnWayne = new GunSlinger("John Wayne");       
	GunSlinger* LeeVanCleef = new GunSlinger("Lee vanCleef");

	Camera* c1 = new Camera(LeeVanCleef);                       
	Camera* c2 = new Camera(JohnWayne);
	
	JohnWayne->Attach(c2);
	LeeVanCleef->Attach(c1);

	LeeVanCleef->setTarget(JohnWayne);
	//c1->showClip();
	JohnWayne->setTarget(LeeVanCleef);
	//c2->showClip();

	LeeVanCleef->blink();                                       
	//c1->showClip();
	JohnWayne->shoot();
	//c2->showClip();
	//c1->showClip();
	

	delete JohnWayne;
	delete LeeVanCleef;
	delete c1;
	delete c2;
	int i; cin >> i;
};