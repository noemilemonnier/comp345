// Original code from the web : 
// https://github.com/kamal-choudhary/singly-linked-list
// https://www.codementor.io/codementorteam/a-comprehensive-guide-to-implementation-of-singly-linked-list-using-c_plus_plus-ondlm5azr

#include<iostream>
using namespace std;
struct Node {
	int data;
	Node *next;	
};

class List {
	//part 2 declare the operator>> so class List can access it
friend const istream& operator>>(istream& input, const List& list);

friend const ostream& operator << (ostream& stream, const List& list);
friend const List operator+(const List& a, const List& b);

private:
	Node *head, *tail;
public:
	//default constructor
	List() {
		head=NULL;
		tail=NULL;
	}

	//copy constructor
	List(const List& list){
		this->head = NULL;
		this->tail = NULL;
		Node* temp = list.head;
		while(temp != nullptr){
			this->createnode(temp->data);
			temp = temp->next;
		}
	}
	
	void createnode(int value){
		Node *temp=new Node;
		temp->data=value;
		temp->next=NULL;
		if(head==NULL){
			head=temp;
			tail=temp;
			temp=NULL;
		}
		else{	
			tail->next=temp;
			tail=temp;
		}
	}
	void display(){
		Node *temp=new Node;
		temp=head;
		while(temp!=NULL){
			cout<<temp->data<<"\t";
			temp=temp->next;
		}
	}
	void insert_start(int value){
		Node *temp=new Node;
		temp->data=value;
		temp->next=head;
		head=temp;
	}
	void insert_position(int pos, int value){
		Node *pre=new Node;
		Node *cur=new Node;
		Node *temp=new Node;
		cur=head;
		for(int i=1;i<pos;i++){
			pre=cur;
			cur=cur->next;
		}
		temp->data=value;
		pre->next=temp;	
		temp->next=cur;
	}
	void delete_first(){
		Node *temp=new Node;
		temp=head;
		head=head->next;
		delete temp;
	}
	void delete_last(){
		Node *current=new Node;
		Node *previous=new Node;
		current=head;
		while(current->next!=NULL){
			previous=current;
			current=current->next;	
		}
		tail=previous;
		previous->next=NULL;
		delete current;
	}

	void delete_position(int pos){
		Node *current=new Node;
		Node *previous=new Node;
		current=head;
		for(int i=1;i<pos;i++){
			previous=current;
			current=current->next;
		}
		previous->next=current->next;
		delete current; 
	}
 

	//part 4 to delete everything in one list
	void delete_all(){
		Node *current= list.head;
		while(current != nullptr){
			Node* temp = current;
			current=current->next;
			free (temp);	
		}
	}

	//part 4
	friend const List& operator=(const List& list){
		 // check for self-assignment
        if(list == this)
            return *this;
        else{
        	//delete everything left hand side has.
			this->delete_all();
            //use the copy constructor;
			List *temp = list.head;
			//assign left hand side head to point to the new copied list.
			this->head = temp;

        }

	}
};

//part 2 
friend const istream& operator>>(istream &input, const List& list){
		Node *temp = list.head; //so we start at the head of the list
		Node *cur = new Node;	//to store the current value of the input 
		cur->next = nullptr; 	//because it is the last node to be added
		//loop to the last node 
		while(temp != nullptr){
			temp = temp->next; //to get to the end of the list
		}
		//ask the user for input and store it so cur can point to it
		input >> cur->data;
		//make the temp (last node) points to cur so it becomes the last node
		temp->next = cur;
		return input;
}

//part 3 
friend const List operator+(const List& a, const List& b){
	//create a list to add the results
	List c{}; 		
	//get the head of each list
	Node *ptrA = a.head;
	Node *ptrB =b.head;
	while( ptrA != NULL && ptrB != NULL){
		c.createnode(ptrA->data + ptrB->data);
		ptrA=ptrA->next;
		ptrB=ptrB->next;
	}
	return c;

}

//part 1 stream output operator
friend const ostream& operator << (ostream& stream, const List& list){
		Node *temp = list.head;
		while(temp!=nullptr){
			cout<<temp->data<<"\t";
			temp=temp->next;
		}
		return stream;
}

int main(){
	List obj;
	obj.createnode(25);
	obj.createnode(50);
	obj.createnode(90);
	obj.createnode(40);
	cout<<"\n--------------------------------------------------\n";
	cout<<"---------------Displaying All nodes---------------";
	cout<<"\n--------------------------------------------------\n";
	obj.display();
	cout<<"\n--------------------------------------------------\n";
	cout<<"-----------------Inserting At End-----------------";
	cout<<"\n--------------------------------------------------\n";
	obj.createnode(55);
	obj.display();
	cout<<"\n--------------------------------------------------\n";
	cout<<"----------------Inserting At Start----------------";
	cout<<"\n--------------------------------------------------\n";
	obj.insert_start(50);
	obj.display();
	cout<<"\n--------------------------------------------------\n";
	cout<<"-------------Inserting At Particular--------------";
	cout<<"\n--------------------------------------------------\n";
	obj.insert_position(5,60);
	obj.display();
	cout<<"\n--------------------------------------------------\n";
	cout<<"----------------Deleting At Start-----------------";
	cout<<"\n--------------------------------------------------\n";
	obj.delete_first();
	obj.display();
	cout<<"\n--------------------------------------------------\n";
	cout<<"-----------------Deleting At End-------------------";
	cout<<"\n--------------------------------------------------\n";
	obj.delete_last();
	obj.display();
	cout<<"\n--------------------------------------------------\n";
	cout<<"--------------Deleting At Particular--------------";
	cout<<"\n--------------------------------------------------\n";
	obj.delete_position(4);
	obj.display();
	int x; cin >> x;
	return 0;
}