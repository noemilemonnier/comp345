#pragma once
#include <iostream>
#include <string>
#include "MyArray.h"


// main function
int main()
{
	int arr[10] = { 1,2,3,4,5,6,7,8,9,10};

	//create an object of type pointer to MyArray
	MyArray* obj1 = new MyArray(arr);
	//use of copy constructor
	MyArray* copiedArray = new MyArray(*obj1);

	int size = copiedArray->getSize();
	int* theArr = copiedArray->getArray();

	for (int i = 0; i < size; i++) {
		std::cout << theArr[i] << std::endl;
	}

	delete theArr;
	theArr = nullptr;
	delete copiedArray;
	copiedArray = nullptr;


	return 0;
}