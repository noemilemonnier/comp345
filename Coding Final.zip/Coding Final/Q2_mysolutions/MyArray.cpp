#include "MyArray.h"
#include <iostream>


//default constructor
MyArray::MyArray()
{
	theArray = nullptr;
	size = 0;
}

//constructor
MyArray::MyArray(int arr[10]){
	int size= 10;
	theArray = new int[size];

		for(int i =0; i<size; i++){
			if(!isInArray(arr[i])){
				theArray[i] = arr[i];
			}
		}
	
}


//destructor
MyArray::~MyArray()
{
	if(theArray != nullptr){
		delete theArray;
		theArray = nullptr;
		size = NULL;
	}
}

//copy constructor
MyArray::MyArray(const MyArray& obj)
{
	size = obj.size;
	//if it is empty
	if (size = 0)
		theArray = nullptr;
	//if it has at least one element
	else {
		theArray = new int[size]; //set the size of the array
		for (int i = 0; i < size; i++) {
			theArray[i] = obj.theArray[i]; //set theArray to the given array values
		}
	}

}

//assignment operator
const MyArray& MyArray::operator=(const MyArray& obj)
{
	//delete the allocation of theArray
	delete[] theArray;
	theArray = nullptr;

	//get the size of the input
	size = obj.size;
	theArray = new int[size];

	for (int i = 0; i < size; i++) {
		theArray[i] = obj.theArray[i];
	}

	return *this;

}

//to check if a value is in the array
bool MyArray::isInArray(int value) {
	for (int i = 0; i < size; i++) {
		if (theArray[i] == value)
			return true;
	}
	return false;
}
