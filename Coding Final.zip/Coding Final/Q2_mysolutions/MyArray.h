#pragma once
#include <iostream>

class MyArray
{
private:
	// dynamic array declaration as pointer
	int* theArray;
	//size of the array
	int size;
public:
	MyArray(); // default constructor
	~MyArray(); // destructor
	MyArray(int arr[]); // constructor
	MyArray(const MyArray& obj); //copy constructor
	const MyArray& operator= (const MyArray& obj); // assignment operator
	bool isInArray(int value); // to check if a value is in the array
	inline int* getArray() { return theArray; }; //to get theArray
	inline int getSize() { return size; }; //to get the size of the stored array

};

