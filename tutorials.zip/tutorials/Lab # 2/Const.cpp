#include "stdafx.h"
#include <iostream>
using namespace std;

class Bar{
private:
	int a;
	void aNonConstMethod(){
		a = 100;
	}
	void aConstMethod() const{
		//a = 100; // ERROR!
		//aNonConstMethod(); // ERROR!
	}
};

void foo(const int a){
	cout << a << endl;
	//a = 10; // Compilation error!
}

int main() {
	const int aConstInt = 10;
	int anInt = 20;
	//a = 20; // Error! Cannot modify a const int

	// int* aPtr1 = &aConstInt; // Not okay! aConstInt is const, I cannot point to it by a a pointer to a non-const int
	// since then I would be able to modify the int through the pointer

	const int* aPtrToAConstInt1 = &aConstInt; // Okay, cannot modify aConstInt through the pointer
	const int* aPtrToAConstInt2 = &anInt; // Still okay, even though anInt is NOT constant,
	// we can still point to it by a pointer to a const int

	aPtrToAConstInt1 = NULL; // Okay! The pointer ITSELF is not constant, it can change what memory address it stores
	//aPtrToAConstInt1* = 100; // Not okay! Cannot change the int pointed by the pointer to a const int

	int* const aConstPointer1 = &anInt; // Okay, the pointer is const, it cannot change the memory address it stores
	// and it points to a non-const int, which is fine
	//int* const aConstPointer2 = &aConstInt; // Not okay! Even though the pointer is const, it stores the memory of a non-const int
	// hence we cannot point to a const int, otherwise we would be able to modify it through the ptr
	//aConstPointer1 = NULL; // Not okay! The pointer is const, cannot change its value.

	const int* const aConstPointerToConstInt1 = &anInt; // Okay!
	const int* const aConstPointerToConstInt2 = &aConstInt; // Okay!
	//aConstPointerToConstInt1 = NULL; // Not okay!
	//*aConstPointerToConstInt1 = 100; // Not okay!

	return 0;
}
