#include "stdafx.h"
#include <iostream>
#include <string>
using namespace std;

class Person{
public:
	// aName is passed as const-reference
	// we are initializing the member
	Person(const std::string& aName, int anAge) : name(aName), age(anAge){
	}
	// Returns a const reference to the class member.
	// The method itself is const as well, it cannot modify the class members 
	// or call non-const member methods.
	const std::string& getName() const{
		return name;
	}

	int getAge() const{
		return age;
	}

	std::string toString() const{
		return name + ", " + std::to_string(age);
	}
	// These members are protected, only visible to its children 
	// (different from java's protected)
protected:
	std::string name;
	int age;
};

class Student : public Person{
public:
	Student(const std::string& name, int anAge, double aGPA) :
		Person(name, anAge), GPA(aGPA){
	} // The syntax to call the parent constructor

	double getGpa() const{
		return GPA;
	}

	std::string toString() const{
		// Note the syntax to call the methode from the parent's class.
		// We do not use super() like in Java, since C++ supports multiple inheritance
		std::string nameAndAge = Person::toString();
		return nameAndAge + ", GPA: " + std::to_string(GPA);
	}
protected:
	double GPA;
};


int main() {
	Person p("Bob", 21);
	Student s("Alice", 20, 4.3);

	std::cout << p.toString() << std::endl;
	std::cout << s.toString() << std::endl;

	// std::cout << p.name << std::endl; Error, the member name is protected

	return 0;
}
