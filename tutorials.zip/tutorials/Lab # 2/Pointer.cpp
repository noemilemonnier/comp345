#include "stdafx.h"
#include <iostream>
using namespace std;

void swap(int& i, int &j){
	int temp = i;
	i = j;
	j = temp;
}

int* foo(){
	int localInt = 10;
	return &localInt;
}

class Bar{
};

void f(int& x){

}

int main()
{
	int* p = NULL;
	f(p);
	int a = 100;
	int& aRef = a;  // Another way to refer to the variable a
	int* aPtr = &a; // Take the address of a an assign it to the pointer

	cout << a << endl; // Prints the value of a.
	cout << &a << endl; // Prints the memory address of the variable a.
	cout << aRef << endl; // Prints the value of a. (Because aRef IS a, just a different name)
	cout << aPtr << endl; // Prints the value of pointer aPtr, which is a memory address, in this case, of a.
	cout << *aPtr << endl; // Prints the value of the variable at the memory address stored in aPtr, which is a.
	cout << &aPtr << endl; // Prints the address of the pointer variable aPtr. Because pointers are types,
	// they also are stored in the memory, under some memory address.
	cout << &*aPtr << endl; // Take the variable located at the memory address stored in aPtr (variable a), then take
	// its address
	cout << *&aPtr << endl; // Take the address of the variable aPtr (not its value, which is the address of variable a,
	// but the address of the variable aPtr itself), then take the value of the variable stored
	// at that address
	int i1 = 10;
	int i2 = 20;
	swap(i1, i2);
	cout << i1 << ' ' << i2 << endl;

	// What memory addresses can pointers store?
	int* aNullPointer = NULL; // Null pointer, stores 0 as memory address, completely valid, but do not dereference
	int* aWildPointer; // Initialized with garbage value, points to a random location
	int* aDanglingPointer = foo(); // Points to a variable that does not exist anymore.
	// Can we assign pointers any memory address? Yes we can!
	int* pleaseDoNotDereference = reinterpret_cast<int*>(0x666); // One way ticket to hell
	// Can we assign memory of an variable of COMPLETELY unrelated type? Of course!
	Bar b;
	int* iHaveNoIdeaWhatIamDoing = (int*)&b;

	return 0;
}