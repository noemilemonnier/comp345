#include "stdafx.h"
#include "ShapeFactory.h"


ShapeFactory::ShapeFactory() {}

ShapeFactory::~ShapeFactory() {}

Shape* ShapeFactory::Create(string type)
{
	if (type == "circle")
		return new Circle();
	if (type == "square")
		return new Square();
	if (type == "triangle")
		return new Triangle();
	return NULL;
}

