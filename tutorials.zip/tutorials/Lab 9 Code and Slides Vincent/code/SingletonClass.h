#pragma once

class SingletonClass
{
private:
	int m_value;
	static SingletonClass* s_instance;// = NULL;
	SingletonClass();

public:
	~SingletonClass();
	int get_value();
	void increment_value();
	static SingletonClass* instance(); //lazy instantiation
	static void ResetInstance(); //to delete/reset the Singleton
};
