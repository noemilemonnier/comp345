#include "stdafx.h"
#include "Cook.h"
/*
//Pizza Builder Client
int main()
{
	Cook cook;															//Create the Director 
	PizzaBuilder* hawaiianPizzaBuilder = new HawaiianPizzaBuilder();	//Create the Concrete Builder

	PizzaBuilder* spicyPizzaBuilder = new SpicyPizzaBuilder();

	cook.setPizzaBuilder(hawaiianPizzaBuilder); //Tell the Director which Builder to use
	cook.constructPizza();						//Tell the Director to construct the Product
	Pizza* hawaiian = cook.getPizza();			//Client gets the Product
	hawaiian->open();							//Client uses the Product

	cook.setPizzaBuilder(spicyPizzaBuilder); //same for another kind of product
	cook.constructPizza();
	Pizza* spicy = cook.getPizza();
	spicy->open();

	delete hawaiianPizzaBuilder;
	delete spicyPizzaBuilder;
	delete hawaiian;
	delete spicy;

	return 0;
}
/**/