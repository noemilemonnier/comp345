#include "stdafx.h"
#include "Shape.h"
#include <iostream>

using std::cout;
using std::endl;

Shape::Shape() {}

Shape::~Shape() {}

Square::~Square() {}

void Square::draw()
{
	cout << "I am square" << endl;
}

Circle::~Circle() {}

void Circle::draw()
{
	cout << "I am circle" << endl;
}

Triangle::~Triangle() {}

void Triangle::draw()
{
	cout << "I am triangle" << endl;
}