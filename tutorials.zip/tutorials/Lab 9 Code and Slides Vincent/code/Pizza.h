#pragma once
#include <string>
using std::string;

//Superclass of all kinds of objects to be created
//Generically called �Product�
class Pizza
{
public:
	Pizza();
	~Pizza();

	//Set all parts of the Product, and use the Product
	void setDough(const string& dough);
	void setSauce(const string& sauce);
	void setTopping(const string& topping);
	void open() const;

private:
	//Parts of the Product
	string m_dough;
	string m_sauce;
	string m_topping;
};


