#include "stdafx.h"
#include "ShapeFactory.h"
#include "ShapeFactory.h"
/*
int main()
{
	// Give me a circle
	Shape* shape1 = ShapeFactory::Create("circle");

	// Give me a square
	Shape* shape2 = ShapeFactory::Create("square");
	
	// Give me a Triangle
	Shape* shape3 = ShapeFactory::Create("triangle");

	shape1->draw(); // will call appropriate draw()
	shape2->draw(); // as it is defined as virtual
	shape3->draw();

	delete shape1;
	delete shape2;
	delete shape3;

	return 0;
}
/**/