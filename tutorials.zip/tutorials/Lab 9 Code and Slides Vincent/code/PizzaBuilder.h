#pragma once
#include "Pizza.h"

// Abstract class providing the structure for all 
// concrete pizza builders
class PizzaBuilder
{
public:
	PizzaBuilder();
	virtual ~PizzaBuilder();

	//get the built Pizza from the Builder
	Pizza* getPizza();

	//build a generic empty Pizza
	void createNewPizzaProduct();

	//create each part of the Product according to subtypes
	virtual void buildDough() = 0;
	virtual void buildSauce() = 0;
	virtual void buildTopping() = 0;

protected:
	//Product built by Pizza Builder
	Pizza* m_pizza;
};

class HawaiianPizzaBuilder : public PizzaBuilder //Concrete Builder 1
{
public:
	~HawaiianPizzaBuilder();
	virtual void buildDough();		//Build different parts of the pizza 
									//The construction process could be 
	virtual void buildSauce();		//more complex in a real-life example 
									//The construction of the pizza part 
	virtual void buildTopping();	//depends on the type of pizza. 
};

class SpicyPizzaBuilder : public PizzaBuilder //Concrete Builder 2
{
public:
	~SpicyPizzaBuilder();
	virtual void buildDough();	//The construction process may vary
	virtual void buildSauce();	//across different Concrete Builders. 
	virtual void buildTopping();
};

