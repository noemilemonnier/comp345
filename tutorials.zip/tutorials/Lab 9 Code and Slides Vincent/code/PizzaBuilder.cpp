#include "stdafx.h"
#include "PizzaBuilder.h"


PizzaBuilder::PizzaBuilder()
{
}

PizzaBuilder::~PizzaBuilder()
{
}

//get the built Pizza from the Builder
Pizza* PizzaBuilder::getPizza()
{
	return m_pizza;
}

//build a generic empty Pizza
void PizzaBuilder::createNewPizzaProduct()
{
	m_pizza = new Pizza();
}

HawaiianPizzaBuilder::~HawaiianPizzaBuilder()
{
}

void HawaiianPizzaBuilder::buildDough()
{
	m_pizza->setDough("cross");
}

void HawaiianPizzaBuilder::buildSauce()
{
	m_pizza->setSauce("mild");
}

void HawaiianPizzaBuilder::buildTopping()
{
	m_pizza->setTopping("ham+pineapple");
}

SpicyPizzaBuilder::~SpicyPizzaBuilder()
{
}

void SpicyPizzaBuilder::buildDough()
{
	m_pizza->setDough("pan baked");
}

void SpicyPizzaBuilder::buildSauce()
{
	m_pizza->setSauce("hot");
}

void SpicyPizzaBuilder::buildTopping()
{
	m_pizza->setTopping("pepperoni+salami");
}