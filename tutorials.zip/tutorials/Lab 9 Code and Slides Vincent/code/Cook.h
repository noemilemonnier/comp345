#pragma once
#include "PizzaBuilder.h"


class Cook //Director
{
public:
	Cook();
	~Cook();
	void setPizzaBuilder(PizzaBuilder* pb); //Use a concrete builder for building a specific kind of Pizza.
	
	Pizza* getPizza(); //get the constructed Pizza

	void constructPizza(); //Creational process to create a pizza using the builder. 

private:
	PizzaBuilder * m_pizzaBuilder;
};