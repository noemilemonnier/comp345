#include "stdafx.h"
#include "SingletonClass.h"
#include <iostream>

using std::cout;
using std::endl;
/*

void foo(void)
{
	SingletonClass::instance()->increment_value();
	cout << "foo: global_ptr is " << SingletonClass::instance()->get_value() << '\n';
}

void bar(void)
{
	SingletonClass::instance()->increment_value();
	cout << "bar: global_ptr is " << SingletonClass::instance()->get_value() << '\n';
}

int main(int argc, char* argv[])
{
	cout << "main: global_ptr is " << SingletonClass::instance()->get_value() << '\n';
	foo();
	bar();
	//SingletonClass s = new SingletonClass();	//won't work since Private!
	//delete s_instance;						//also won't for the same reason

	SingletonClass::ResetInstance();		//deletes/resets the Singleton 
	
	return 0;
}
/**/