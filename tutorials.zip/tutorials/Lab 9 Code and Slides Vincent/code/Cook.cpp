#include "stdafx.h"
#include "Cook.h"


Cook::Cook()
{
}


Cook::~Cook()
{
}

void Cook::setPizzaBuilder(PizzaBuilder* pb)	//Use a concrete builder
{												//for building a specific
	m_pizzaBuilder = pb;						//kind of Pizza.
}

Pizza* Cook::getPizza()							//get the constructed Pizza
{
	return m_pizzaBuilder->getPizza();
}

void Cook::constructPizza()						//Creational process to create 
{												//a pizza using the builder. 
	m_pizzaBuilder->createNewPizzaProduct();
	m_pizzaBuilder->buildDough();
	m_pizzaBuilder->buildSauce();
	m_pizzaBuilder->buildTopping();
}