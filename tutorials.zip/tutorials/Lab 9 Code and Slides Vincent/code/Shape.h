#pragma once

//Abstract base class
class Shape
{
public:
	Shape();
	virtual ~Shape();
	virtual void draw() = 0;
};

class Square : public Shape
{ 
public:
	~Square();
	void draw();
};

class Circle : public Shape
{
public:
	~Circle();
	void draw();
};

class Triangle : public Shape
{
public:
	~Triangle();
	void draw();
};
