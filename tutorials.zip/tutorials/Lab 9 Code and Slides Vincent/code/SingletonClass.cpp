#include "stdafx.h"
#include "SingletonClass.h"

// Allocating and initializing SingletonClass's
// static data member. The pointer is being
// allocated -not the object itself.
SingletonClass* SingletonClass::s_instance = 0;

SingletonClass::SingletonClass()
{
	m_value = 0;
}


SingletonClass::~SingletonClass()
{
}

int SingletonClass::get_value()
{
	return m_value;
}

void SingletonClass::increment_value()
{
	m_value++;
}

SingletonClass* SingletonClass::instance()
{
	if (!s_instance)
		s_instance = new SingletonClass();
	return s_instance;
}

void SingletonClass::ResetInstance()
{
	delete s_instance;
	s_instance = NULL; 
}
