#pragma once
#include<iostream>
#include "Widget.h"

using namespace std;

class MotifMenu : public Widget {
public:
	void draw() { cout << "MotifMenu" << endl; }
};

