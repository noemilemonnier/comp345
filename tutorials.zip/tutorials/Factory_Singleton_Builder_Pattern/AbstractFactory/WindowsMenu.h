#pragma once
#include<iostream>
#include "Widget.h"

using namespace std;

class WindowsMenu : public Widget {
public:
	void draw() { cout << "WindowsMenu" << endl; }
};

