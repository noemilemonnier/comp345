/*
 
 it is like a factory , but everything is encapsulated
    the method that orders
    the factory that builds the object
    the final object
    the final object contains the object that uses the strategy pattern
        Composition : Object class fields are object
 
 Abstract factory creates families of realted object without specifying a concrete class
 Use when you have many objects that can be added or changed dynamically during runtime
 
 you can model anything you can imagine and have those objects interact throuhg common interfaces
 
 BAD: Things get complicated
 */





#include "WindowsWidgetFactory.h"
#include "MotifWidgetFactory.h"
#include "Widget.h"

#define MOTIF

int main(int argc, char *argv[])
{
	WidgetFactory *widget_factory;
#ifdef MOTIF
	widget_factory = new MotifWidgetFactory;
#else // WINDOWS
	widget_factory = new WindowsWidgetFactory;
#endif

	Widget* w[2] = { widget_factory->create_button(),
		widget_factory->create_menu() };
	w[0]->draw();
	w[1]->draw();

}
