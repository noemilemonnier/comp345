#pragma once
#include "WidgetFactory.h"
#include "WindowsButton.h"
#include "WindowsMenu.h"

class WindowsWidgetFactory : public WidgetFactory {
public:
	Widget* create_button() {
		return new WindowsButton;
	}
	Widget* create_menu() {
		return new WindowsMenu;
	}
};

