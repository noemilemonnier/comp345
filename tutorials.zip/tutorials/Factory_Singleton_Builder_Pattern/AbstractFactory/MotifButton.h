#pragma once
#include<iostream>
#include "Widget.h"

using namespace std;

class MotifButton : public Widget {
public:
	void draw() { cout << "MotifButton" << endl; }
};
