#pragma once
class Widget {
public:
	virtual void draw() = 0;
};
