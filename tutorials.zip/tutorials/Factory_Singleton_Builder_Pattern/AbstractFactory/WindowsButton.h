#pragma once
#include<iostream>
#include "Widget.h"

using namespace std;

class WindowsButton : public Widget {
public:
	void draw() { cout << "WindowsButton" << endl; }
};
