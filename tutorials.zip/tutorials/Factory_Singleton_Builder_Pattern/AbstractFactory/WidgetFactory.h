#pragma once
#include "Widget.h"

class WidgetFactory {
public:
	virtual Widget* create_button() = 0;
	virtual Widget* create_menu() = 0;
};
