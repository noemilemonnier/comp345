#pragma once
#include "WidgetFactory.h"
#include "MotifButton.h"
#include "MotifMenu.h"

class MotifWidgetFactory : public WidgetFactory {
public:
	Widget* create_button() {
		return new MotifButton;
	}
	Widget* create_menu() {
		return new MotifMenu;
	}
};


//

