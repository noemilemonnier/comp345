#pragma once
#include<iostream>
#include "SingletonClass.h"

class SingletonDestroyer {

public:
	SingletonDestroyer(SingletonClass* instance = 0) {
		_singleton = instance;
	}

	void setSingleton(SingletonClass* singleton) {
		_singleton = singleton;
	}

	~SingletonDestroyer() {
		delete _singleton;
	}

private:
	SingletonClass* _singleton = 0;
};
