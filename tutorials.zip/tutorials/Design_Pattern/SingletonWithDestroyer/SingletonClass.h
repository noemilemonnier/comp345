#pragma once
#include "SingletonDestroyer.h"

class SingletonClass
{
private:
	int m_value;
	static SingletonClass *s_instance;
	SingletonClass()
	{
		m_value = 0;
	}

	static SingletonDestroyer _destroyer;

public:
	int get_value()
	{
		return m_value;
	}
	void increment_value()
	{
		m_value++;
	}
	static SingletonClass *instance() {
		if (!s_instance) {
			s_instance = new SingletonClass();
			_destroyer.setSingleton(s_instance);
		}
		return s_instance;
	}

	static SingletonDestroyer getDestroyer() {
		return _destroyer;
	}
protected:
	virtual ~SingletonClass() {};

	friend class SingletonDestroyer;
};

// Allocating and initializing SingletonClass's
// static data member.  The pointer is being
// allocated - not the object itself.
SingletonClass *SingletonClass::s_instance = 0;

