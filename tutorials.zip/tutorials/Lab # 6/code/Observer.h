#pragma once

//Note: Abstract class due to virtual AND = 0
class Observer 
{
public:
	~Observer();
	virtual void Update() = 0;

protected:
	Observer();
};
