#include "stdafx.h"
#include <iostream>
#include <string>
#include <vector>
/*
using std::vector;
using std::string;
using std::cout;
using std::endl;

//printing function with a loop and an iterator
void printContentsOfVector1(vector<double> a)
{
	vector<double>::iterator it;
	cout << "Printing contents of vector (version 1): ";
	for (it = a.begin(); it < a.end(); it++ )
		cout << " " << *it;
	cout << endl;
}

//printing function with a loop and at function
void printContentsOfVector2(vector<double> a)
{
	cout << "Printing contents of vector (version 2): ";
	for (int i = 0; i < a.size(); i++)
		cout << " " << a.at(i);
	cout << endl;
}

//printing function with a loop and array index syntax
void printContentsOfVector3(vector<int> a)
{
	cout << "Printing contents of vector (version 3): ";
	for (int i = 0; i < a.size(); i++)
		cout << " " << a[i];
	cout << endl;
}

//printing function with a loop and array index syntax for dynamic int objects
void printContentsOfVector4(vector<int*> a)
{
	cout << "Printing contents of vector (version 4): ";
	for (int i = 0; i < a.size(); i++)
		cout << " " << *(a[i]); //dereferences to print contents
		//cout << " " << a[i]; //prints the addresses
	cout << endl;
}
int main()
{
	vector<double> aVectorOfDoubles; //declare and initialize empty vector

	cout << "Size of aVectorOfDouble: " << aVectorOfDoubles.size() << endl; //should be empty

	//populate vector by adding at end
	aVectorOfDoubles.push_back(1.1);
	aVectorOfDoubles.push_back(2.2);
	aVectorOfDoubles.push_back(3.3);

	cout << "Size of aVectorOfDouble: " << aVectorOfDoubles.size() << endl; //should be 3
	printContentsOfVector1(aVectorOfDoubles);

	vector<double>::iterator it = aVectorOfDoubles.begin(); //declare and initialize vector iterator
	//aVectorOfDoubles.erase(1); //bad syntax
	aVectorOfDoubles.erase(it+1); //good syntax and erasing element at position 2
	
	printContentsOfVector2(aVectorOfDoubles);

	cout << "Size of aVectorOfDouble: " << aVectorOfDoubles.size() << endl; //should be 2
	

	aVectorOfDoubles.resize(1);	//truncates from end

	cout << "Size of aVectorOfDouble: " << aVectorOfDoubles.size() << endl; //should be 1
	
	//cout << "aVectorOfDouble at 0: " << aVectorOfDoubles.at(1) << endl; //run time error
	printContentsOfVector1(aVectorOfDoubles);


	aVectorOfDoubles.pop_back(); //pop off from end
	cout << "Size of aVectorOfDouble: " << aVectorOfDoubles.size() << endl;
	printContentsOfVector1(aVectorOfDoubles);

	vector<int> aVectorOfInts1(2); //fills it with default of data type

	cout << "Size of aVectorOfInts1: " << aVectorOfInts1.size() << endl; //this will print size 2
	//printContentsOfVector2(aVectorOfInts1); //won't work since function is expecting double
	printContentsOfVector3(aVectorOfInts1); //will work and will print default values

	vector<int> aVectorOfInts2(5, 2);

	cout << "Size of aVectorOfInts2: " << aVectorOfInts2.size() << endl; //should be 5
	printContentsOfVector3(aVectorOfInts2);
	vector<int>::iterator it2 = aVectorOfInts2.begin();

	aVectorOfInts2.insert(it2+1, 42); //adding value 42 at 2nd position (starting from 1) 
	printContentsOfVector3(aVectorOfInts2);

	it2 = aVectorOfInts2.begin(); //note this is needed for following to work properly, or else run time error!
	aVectorOfInts2.insert(it2+2, 55); //adding value 55 at 3rd position (starting from 1) 
	printContentsOfVector3(aVectorOfInts2);

	//dynamic objects in a vector
	vector<int*> vectorOfDynamicInts;
	vectorOfDynamicInts.push_back(new int(1));
	vectorOfDynamicInts.push_back(new int(2));
	vectorOfDynamicInts.push_back(new int(3));
	cout << "Size of vectorOfDynamicInts: " << vectorOfDynamicInts.size() << endl; //should be 3
	printContentsOfVector4(vectorOfDynamicInts);


	//must handle memory deallocation
	for (int i = 0; i < vectorOfDynamicInts.size(); i++)
	{
		delete vectorOfDynamicInts[i];
		vectorOfDynamicInts[i] = NULL;
	}
	cout << "Size of vectorOfDynamicInts: " << vectorOfDynamicInts.size() << endl; //should still be 3
	
	vectorOfDynamicInts.clear(); //will remove the "placeholder memory locations"
	cout << "Size of vectorOfDynamicInts: " << vectorOfDynamicInts.size() << endl; //should be 0

	return 0;
}
*/