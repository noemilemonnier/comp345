#include "stdafx.h"
#include "Observer.h"

Observer::Observer(){};

Observer::~Observer(){};
