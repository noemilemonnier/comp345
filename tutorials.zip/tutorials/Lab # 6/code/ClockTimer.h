#pragma once
#include "Subject.h"

//ConcreteSubject
class ClockTimer : public Subject 
{
public:
	ClockTimer();
	int getHour(){ return hour; };		//defining here
	int getMinute(){ return minute; };	//defining here
	int getSecond(){ return second; };	//defining here
	void start(int time);
	void tick();
	~ClockTimer();

private:
	int hour;
	int minute;
	int second;
};
