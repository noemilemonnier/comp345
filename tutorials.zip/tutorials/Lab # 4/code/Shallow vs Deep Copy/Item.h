#pragma once
#include <string>

class Item
{
private:
	std::string nameOfItem;
public:
	Item();
	Item(std::string);
	~Item();
	void setNameOfItem(std::string);
	std::string getNameOfItem();
};

