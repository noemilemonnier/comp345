#include "stdafx.h"
#include "SmashCharacter.h"
#include <iostream>

using std::string;

SmashCharacter::SmashCharacter() : it(NULL), nameOfCharacter("") {}

SmashCharacter::SmashCharacter(Item* i, std::string nOC) : it(i), nameOfCharacter(nOC) {}

//shallow copy version
//SmashCharacter::SmashCharacter(const SmashCharacter &sc) : it(sc.it), nameOfCharacter(sc.nameOfCharacter) {}

/**/
//Deep copy version
SmashCharacter::SmashCharacter(const SmashCharacter &sc)
{
	nameOfCharacter = sc.nameOfCharacter; //can allow shallow copy here since not a pointer

	if (sc.it) //make sure sc it object exists
	{
		it = new Item();

		it->setNameOfItem(sc.it->getNameOfItem());
	}
	else
		it = NULL;
}
/**/

/**/
//overridden assignment operater
SmashCharacter& SmashCharacter::operator=(const SmashCharacter &sc)
{
	//check for self-assignment
	if (this == &sc)
		return *this;

	//delete anything in it
	delete it;

	nameOfCharacter = sc.nameOfCharacter; //can allow shallow copy here since not a pointer

	if (sc.it) //make sure sc it object exists
	{
		it = new Item();

		it->setNameOfItem(sc.it->getNameOfItem());
	}
	else
		it = NULL;
}
/**/
SmashCharacter::~SmashCharacter()
{
	if (it)
		delete it; //Note: don't forget to delete dynamic members!!
}

Item* SmashCharacter::getIt() const
{
	return it; //Note: this can be a wanted shallow copy
}

std::string SmashCharacter::getNameOfCharacter() const
{
	return nameOfCharacter;
}

