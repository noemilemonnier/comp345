#include "stdafx.h"
#include "Item.h"
#include <iostream>

using namespace std;

Item::Item() : nameOfItem("") {}

Item::Item(std::string n) : nameOfItem(n) {}

Item::~Item() {}

void Item::setNameOfItem(std::string nOI)
{
	nameOfItem = nOI;
}

std::string Item::getNameOfItem()
{
	return nameOfItem;
}