#pragma once
#include "Item.h"

class SmashCharacter
{
private:
	Item *it;						//Note: this will be for a dynamic object member!
	std::string nameOfCharacter;

public:
	SmashCharacter();
	SmashCharacter(Item*, std::string);
	SmashCharacter(const SmashCharacter &sc);
	SmashCharacter& operator=(const SmashCharacter &sc);
	~SmashCharacter();
	Item* getIt () const;
	std::string getNameOfCharacter () const;
};

