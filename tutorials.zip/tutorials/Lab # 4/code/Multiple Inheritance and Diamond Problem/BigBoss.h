#pragma once
#include <string>

using std::string; 

//The following are class declarations
//This will show the Diamond Problem due to age and num being ambiguous for WhatAmI

class BigBoss
{
public:
	BigBoss();
	BigBoss(int, string);
	~BigBoss();

public:
	int age;
	string name;
};

class SolidSnake : public BigBoss
{
public:
	SolidSnake();
	SolidSnake(int, string, int);
	~SolidSnake();
	int num;
};

class LiquidSnake : public BigBoss
{
public:
	LiquidSnake();
	LiquidSnake(int, string, int);
	~LiquidSnake();
	int num;
};

class SolidusSnake : public BigBoss
{
public:
	SolidusSnake();
	SolidusSnake(int, string);
	~SolidusSnake();
};

class WhatAmI : public SolidSnake, LiquidSnake, SolidusSnake //Note: this one inherits ambiguous age and num!!
{
public:
	WhatAmI();
	WhatAmI(int, string, int);
	~WhatAmI();
};
