#include "stdafx.h"
#include "BigBoss.h"
#include <iostream>

using std::cout;
using std::endl;
using std::string;

BigBoss::BigBoss() : age(0), name("") 
{
	cout << "I am now in Big Boss's default constructor" << endl;
}

BigBoss::BigBoss(int age, string n) : age(age), name(n) 
{
	cout << "I am now in Big Boss's param constructor" << endl;
}

BigBoss::~BigBoss() 
{
	cout << "I am now in Big Boss's destructor" << endl;
}

SolidSnake::SolidSnake() : BigBoss() 
{
	cout << "I am now in Solid Snake's default constructor" << endl;
}

SolidSnake::SolidSnake(int wtvAge, string n, int i) : BigBoss(wtvAge, n), num(i)
{
	cout << "I am now in Solid Snake's param constructor" << endl;
}

SolidSnake::~SolidSnake() 
{
	cout << "I am now in Solid Snake's destructor" << endl;
}

LiquidSnake::LiquidSnake() : BigBoss() 
{
	cout << "I am now in Liquid Snake's default constructor" << endl;
}

LiquidSnake::LiquidSnake(int wtvAge, string n, int i) : BigBoss(wtvAge, n), num(i)
{
	cout << "I am now in Liquid Snake's param constructor" << endl;
}

LiquidSnake::~LiquidSnake() 
{
	cout << "I am now in Liquid Snake's destructor" << endl;
}

SolidusSnake::SolidusSnake() : BigBoss() 
{
	cout << "I am now in Solidus Snake's default constructor" << endl;
}

SolidusSnake::SolidusSnake(int wtvAge, string n) : BigBoss(wtvAge, n) 
{
	cout << "I am now in Solidus Snake's param constructor" << endl;
}

SolidusSnake::~SolidusSnake() 
{
	cout << "I am now in Solidus Snake's destructor" << endl;
}

WhatAmI::WhatAmI() : SolidSnake(), LiquidSnake(), SolidusSnake() 
{
	cout << "I am now in WhatAmI's default constructor" << endl;
}

WhatAmI::WhatAmI(int a, string n, int i) : SolidSnake(a, n, i), LiquidSnake(a, n, i), SolidusSnake(a, n)
{
	cout << "I am now in WhatAmI's param constructor" << endl;
}

WhatAmI::~WhatAmI() 
{
	cout << "I am now in WhatAmI's destructor" << endl;
}