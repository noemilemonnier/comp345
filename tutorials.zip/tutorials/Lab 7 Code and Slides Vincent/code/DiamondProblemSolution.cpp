#include "stdafx.h"

class Animal
{
public:
	virtual ~Animal() { }
	virtual void eat() {}
};

//class Mammal : Animal
class Mammal : virtual public Animal
{
public:
	virtual void breathe() {}
};

//class WingedAnimal : Animal
class WingedAnimal : virtual public Animal
{
public:
	virtual void flap() {}
};

// A bat is a winged mammal
class Bat : public Mammal, WingedAnimal {};

int main()
{
	/*
	//for without virtual inheritance
	Bat bat;
	bat.eat(); //ambiguous since two Animals in Bat

	Bat b;
	Animal &a = b; // error: which Animal subobject should a Bat cast into, 
			   // a Mammal::Animal or a WingedAnimal::Animal?
	
	*/

	/**/
	//for with virtual inheritance
	Bat bat;
	bat.eat();

	Bat b;
	Animal &a = b;
	/**/
	return 0;
}