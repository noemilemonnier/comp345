#pragma once

#include "stdafx.h"
#include <iostream>

using namespace std;
/*
class Bar{
private:
	int a;
	void aNonConstMethod(){
		a = 100;
	}
	void aConstMethod() const{
		//a = 100; // ERROR!
		//aNonConstMethod(); // ERROR!
	}
};

void foo(const int a){
	cout << a << endl;
	//a = 10; // Compilation error!
}

int main() {
	const int aConstInt = 10;
	int anInt = 20;
	//a = 20; // Error! Cannot modify a const int

	// int* aPtr1 = &aConstInt; // Not okay! aConstInt is const, I cannot point to it by a a pointer to a non-const int
	// since then I would be able to modify the int through the pointer

	const int* aPtrToAConstInt1 = &aConstInt; // Okay, cannot modify aConstInt through the pointer
	const int* aPtrToAConstInt2 = &anInt; // Still okay, even though anInt is NOT constant,

	//*aPtrToAConstInt2 = 2; //error
	cout << "Before const cast for anInt: " << anInt << endl;
	int *aPtrToAConstInt3 = const_cast<int*>(aPtrToAConstInt2); // "hacking"
	*aPtrToAConstInt3 += 10;
	cout << "After const cast for anInt: " << anInt << endl;

	cout << "Before const cast for aConstInt: " << aConstInt << endl;
	int *aPtrToAConstInt4 = const_cast<int*>(aPtrToAConstInt1); // "hacking"
	*aPtrToAConstInt4 = 30; //allowed? Yes
	cout << "After const cast for aConstInt: " << aConstInt << endl; //still 10
	cout << "value of aPtrToAConstInt4: " << *aPtrToAConstInt4 << endl; //30
	cout << "value of aPtrToAConstInt1: " << *aPtrToAConstInt1 << endl; //still 30
	cout << "After const cast for aConstInt: " << aConstInt << endl; //still 10



	const int *aPtrToAConstInt5 = &anInt; // Still okay, even though anInt is NOT constant,
	// we can still point to it by a pointer to a const int
	//aPtrToAConstInt2 = aPtrToAConstInt1; //good
	//*aPtrToAConstInt2 = 3; //not good since trying to change aConstInt without const cast

	return 0;
}
*/