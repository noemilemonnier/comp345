
#pragma once
#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
/**/
int main()
{
	//for version 2 to make sure GPAs print correctly .0
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(1);


  // Open a file
  
  ofstream output;

  //for version 2 to make sure GPAs write correctly with .0
  output.setf(ios::fixed);
  output.setf(ios::showpoint);
  output.precision(1);
  
  /*
  //version 1
  //will open file, or create it if it does not exist
  //Note: if leave only this one, it will rewrite over text file, and never append
  output.open("scores.txt"); 

  //This one will append
 // output.open("scores.txt", ios::out | ios::app); //appending

  output << 100 << endl;
  output << 75 << endl;
  output << 0 << endl;
  output << 55 << endl;
  output << 45 << endl;
  output << 85 << endl;
  output << 90 << endl;
  output << 0 << endl;
  */

  /**/
  //version 2
  output.open("WatchmenScores.txt"); //will creaye
  //format: 2 strings, 1 int, 1 string, 1 double 
  output << "Johnathan Osterman " << 100 << " A+ " << 4.3 << endl;
  output << "Edward Blake " << 75 << " B+ " << 3.3 << endl;
  output << "Walter Kovas " << 60 << " C+ " << 2.3 << endl;
  output << "Daniel Dreiberg " << 85 << " A " << 4.0 << endl;
  output << "Laurie Jupiter " << 80 << " A- " << 3.7 << endl;
  /**/

  output.close(); //close output stream; note: must close before input stream opens
  /**/
  
  //ifstream input("scores.txt"); //for version 1
  ifstream input("WatchmenScores.txt"); //for version 2

  if (input.fail())
  {
    cout << "File does not exist" << endl;
    cout << "Exit program" << endl;
    return 0;
  }
  /*
  for version 1
  double sum = 0;
  */
  /**/
  string fName, lName, letterGrade;
  int numGrade;
  double GPA;

  //while (input >> numGrade) // Read data to the end of file for version 1
  while (true) // Read data to the end of file for version 2
  {
	  //cout << number << " "; // Display data for version 1

	  //version2
	  input >> fName >> lName >> numGrade >> letterGrade >> GPA;
	  if (input.eof()) //enter here if end of file to not print last line twice!!!
		  break;
	  else //enter here if not end of file
		  cout << fName << " " << lName << " " << numGrade << " " << letterGrade << " " << GPA << endl; // Display data for version 2
	  //end of version 2

	  //sum += number; for version 1 
  }
  
  input.close(); //close input stream

  //cout << "\nTotal is " << sum << endl; //for version 1
  
  return 0;
}
/**/