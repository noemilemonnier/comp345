#pragma once
#include<string>

using std::string;

/**
 * The RoundPeg class.
 * This is the Adaptee class.
 */
class RoundPeg 
{
public:
	virtual void insertIntoRoundHole(string str);
};
