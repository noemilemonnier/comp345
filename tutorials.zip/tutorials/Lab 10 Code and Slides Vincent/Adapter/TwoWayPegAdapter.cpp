#include "stdafx.h"
#include "TwoWayPegAdapter.h"
#include <iostream>

using std::cout;
using std::endl;

TwoWayPegAdapter::TwoWayPegAdapter(RoundPeg *peg) 
{
	//a roundPeg is plugged into the adapter
	roundPeg = peg;
	squarePeg = NULL;
}

TwoWayPegAdapter::TwoWayPegAdapter(SquarePeg *peg) 
{
	//a squarePeg is plugged into the adapter
	squarePeg = peg;
	roundPeg = NULL;
}
void TwoWayPegAdapter::insertIntoRoundHole(string str) 
{
	cout << "TwoWayAdapter insertIntoSquareHole()" << endl;
	squarePeg->insertIntoSquareHole(str);
}
void TwoWayPegAdapter::insertIntoSquareHole(string str) 
{
	cout << "TwoWayAdapter insertIntoRoundHole()" << endl;
	roundPeg->insertIntoRoundHole(str);
}