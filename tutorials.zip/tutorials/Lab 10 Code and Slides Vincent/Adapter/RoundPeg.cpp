#include "stdafx.h"
#include "RoundPeg.h"
#include<iostream>

using std::cout;
using std::endl;

void RoundPeg::insertIntoRoundHole(string str) 
{
	cout << "RoundPeg insertIntoRoundHole(): " << str << endl;
}