#pragma once
#include "SquarePeg.h"
#include "RoundPeg.h"

class TwoWayPegAdapter : public SquarePeg, public RoundPeg 
{
private:
	RoundPeg *roundPeg;
	SquarePeg *squarePeg;
public:
	TwoWayPegAdapter(RoundPeg *peg);
	TwoWayPegAdapter(SquarePeg *peg);
	void insertIntoRoundHole(string str);
	void insertIntoSquareHole(string str);
};

