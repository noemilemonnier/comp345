#pragma once
#include "SquarePeg.h"
#include "RoundPeg.h"

/**
 * The SquareToRoundPegAdapter class.
 * This is the Adapter class.
 * It adapts a SquarePeg to a RoundPeg.
 * Its interface is that of a SquarePeg.
 */
class SquareToRoundPegAdapter : public SquarePeg 
{
private:
	RoundPeg roundPeg;
public:
	SquareToRoundPegAdapter(RoundPeg peg);
	void insertIntoSquareHole(string str);
};

