#include "stdafx.h"
#include "SquarePeg.h"
#include <iostream>

using std::cout;
using std::endl;

void SquarePeg::insertIntoSquareHole(string str) 
{
	cout << "SquarePeg insertIntoSquareHole(): " << str << endl;
}