#include "stdafx.h"
#include "SquareToRoundPegAdapter.h"
#include <iostream>

using std::cout;
using std::endl;

SquareToRoundPegAdapter::SquareToRoundPegAdapter(RoundPeg peg)
{
	//the roundPeg is plugged into the adapter
	roundPeg = peg;
}
void SquareToRoundPegAdapter::insertIntoSquareHole(string str)
{
	cout << "SquareToRoundPegAdapter insertIntoSquareHole()" << endl;
	//the roundPeg can now be inserted in the same manner as a squarePeg!
	roundPeg.insertIntoRoundHole(str);
}