#pragma once
#include<string>

using std::string;

/**
* The RoundPeg class.
* This is the Target class.
*/
class SquarePeg 
{
public:
	virtual void insertIntoSquareHole(string str);
};
