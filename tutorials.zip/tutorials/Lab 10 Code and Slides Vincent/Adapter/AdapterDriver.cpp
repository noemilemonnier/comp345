#include "stdafx.h"
/*
#include "SquareToRoundPegAdapter.h"
#include "TwoWayPegAdapter.h"

int main(int argc, char *argv[])
{
	// Create some pegs.
	RoundPeg *roundPeg = new RoundPeg();
	SquarePeg *squarePeg = new SquarePeg();

	// Do an insert using the square peg.
	squarePeg->insertIntoSquareHole("Inserting square peg...\n\n");

	// Now we'd like to do an insert using the round peg.
	// But this client only understands the insert()
	// method of pegs, not a insertIntoHole() method.
	// The solution: create an adapter that adapts
	// a square peg to a round peg!

	SquareToRoundPegAdapter *adapter = new SquareToRoundPegAdapter(*roundPeg);
	adapter->insertIntoSquareHole("Inserting round peg...\n\n");


	SquarePeg *sq_pegs[2] = { new SquarePeg(),
		new SquareToRoundPegAdapter(*roundPeg) };
	sq_pegs[0]->insertIntoSquareHole("Inserting square peg [0]...");
	sq_pegs[1]->insertIntoSquareHole("Inserting square peg [1]...\n\n");


	// Using two way adapter.
	TwoWayPegAdapter *a = new TwoWayPegAdapter(roundPeg);	//Note: different from slides to actually be able to delete this dynamic memory
	TwoWayPegAdapter *b = new TwoWayPegAdapter(squarePeg);	//Note: different from slides to actually be able to delete this dynamic memory

	SquarePeg *squarePegArray[2] = { squarePeg, a};
	squarePegArray[0]->insertIntoSquareHole("Inserting Square Peg in squarePegArray[0]...");
	squarePegArray[1]->insertIntoSquareHole("Inserting Square Peg in squarePegArray[1]...\n\n");

	RoundPeg *roundPegArray[2] = { roundPeg, b};
	roundPegArray[0]->insertIntoRoundHole("Inserting Round Peg in roundPegArray[0]...");
	roundPegArray[1]->insertIntoRoundHole("Inserting Round Peg in roundPegArray[1]...\n\n");

	//clear dynamic memory
	delete sq_pegs[0];
	delete sq_pegs[1];
	delete roundPeg;
	delete squarePeg;
	delete adapter;
	delete a;
	delete b;
	
	system("PAUSE");
	return 0;
	
}
/**/