#include "stdafx.h"
#include "CoffeeDecorator.h"

CoffeeDecorator::CoffeeDecorator(Coffee *decoratedCoffee) 
{
	this->decoratedCoffee = decoratedCoffee;
}

double CoffeeDecorator::getCost() 
{
	return decoratedCoffee->getCost();
}

string CoffeeDecorator::getIngredients() 
{
	return decoratedCoffee->getIngredients();
}