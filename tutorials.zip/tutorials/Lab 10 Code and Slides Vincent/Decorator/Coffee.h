#pragma once
#include<string>

using std::string;

/**
* The abstract Coffee class (actually interface) defines the functionality of any Coffee
* implemented by subclasses of Coffee
*/
class Coffee 
{
public:
	virtual double getCost() = 0;
	virtual string getIngredients() = 0;
};

