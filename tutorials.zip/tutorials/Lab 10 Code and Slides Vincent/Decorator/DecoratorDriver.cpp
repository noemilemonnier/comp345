#include "stdafx.h"
/*
#include "SimpleCoffee.h"
#include "CoffeeDecorator.h"
#include "Sprinkles.h"
#include "Expresso.h"
#include "Milk.h"
#include "Whip.h"
#include<iostream>

using std::cout;
using std::endl;

int main() 
{
	Coffee *c = new SimpleCoffee();
	cout << "Cost: " << c->getCost() << " Ingredients : " << c->getIngredients() << endl;
	SimpleCoffee* sc = dynamic_cast<SimpleCoffee*>(c);	//only for proper memory deletion of this example

	c = new Milk(c);
	cout << "Cost: " << c->getCost() << " Ingredients : " << c->getIngredients() << endl;
	Milk* m1 = dynamic_cast<Milk*>(c);	//only for proper memory deletion of this example

	c = new Sprinkles(c);
	cout << "Cost: " << c->getCost() << " Ingredients : " << c->getIngredients() << endl;
	Sprinkles* sp1 = dynamic_cast<Sprinkles*>(c);	//only for proper memory deletion of this example

	c = new Whip(c);
	cout << "Cost: " << c->getCost() << " Ingredients : " << c->getIngredients() << endl;
	Whip* w = dynamic_cast<Whip*>(c);	//only for proper memory deletion of this example

	// Note that you can also stack more than one decorator of the same type
	c = new Sprinkles(c);
	cout << "Cost: " << c->getCost() << " Ingredients : " << c->getIngredients() << endl;
	Sprinkles* sp2 = dynamic_cast<Sprinkles*>(c);	//only for proper memory deletion of this example

	c = new Espresso();
	cout << "Cost: " << c->getCost() << " Ingredients : " << c->getIngredients() << endl;
	Espresso* e = dynamic_cast<Espresso*>(c);	//only for proper memory deletion of this example

	c = new Milk(c);
	cout << "Cost: " << c->getCost() << " Ingredients : " << c->getIngredients() << endl;
	Milk* m2 = dynamic_cast<Milk*>(c);	//only for proper memory deletion of this example

	//clear dynamic memory
	//delete c; //not enough
	delete sc;
	delete m1;
	delete m2;
	delete sp1;
	delete sp2;
	delete w;
	delete e;

	system("PAUSE");
	return 0;
}
/**/