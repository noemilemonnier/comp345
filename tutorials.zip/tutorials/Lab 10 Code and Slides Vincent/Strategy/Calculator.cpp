#include "stdafx.h"
#include "Calculator.h"

Calculator::Calculator() {};

Calculator::Calculator(Strategy *initStrategy) 
{
	this->strategy = initStrategy;
}

void Calculator::setStrategy(Strategy *newStrategy)
{
	this->strategy = newStrategy;
}

int Calculator::executeStrategy(int a, int b)
{
	return this->strategy->execute(a, b);
}