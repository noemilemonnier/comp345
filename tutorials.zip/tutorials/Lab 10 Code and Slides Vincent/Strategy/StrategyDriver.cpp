#include "stdafx.h"
/*
#include "Calculator.h"
#include "Add.h"
#include "Subtract.h"
#include "Multiply.h"
#include<iostream>

using std::cout;
using std::endl;

int main() 
{
	//altered from class notes to actually delete strategies
	Strategy *addition = new Add();
	Strategy *subtraction = new Subtract();
	Strategy *multiplication = new Multiply();

	//Calculator calculator(new Add()); //memory leak
	Calculator calculator(addition);
	int resultA = calculator.executeStrategy(3, 4);
	
	//calculator.setStrategy(new Subtract()); //memory leak
	calculator.setStrategy(subtraction);
	int resultB = calculator.executeStrategy(3, 4);
	
	//calculator.setStrategy(new Multiply()); //memory leak
	calculator.setStrategy(multiplication);
	int resultC = calculator.executeStrategy(3, 4);

	cout << "Result of addition strategy: " << resultA << endl;			//result 7
	cout << "Result of subtraction strategy: " << resultB << endl;		//result -1
	cout << "Result of multiplication strategy: " << resultC << endl;	//result 12

	//clear dynamic memory
	delete addition;
	delete subtraction;
	delete multiplication;

	return 0;
}
/**/