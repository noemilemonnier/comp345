#pragma once
#include "Strategy.h"
#include<iostream>

using std::cout;
using std::endl;

/**
* A concrete Strategy that implements a subtraction operation
*/
class Subtract : public Strategy 
{
public:
	int execute(int a, int b) 
	{
		cout << "Called Subtract's execute()" << endl;
		return a - b;
	}

	~Subtract() {}
};

