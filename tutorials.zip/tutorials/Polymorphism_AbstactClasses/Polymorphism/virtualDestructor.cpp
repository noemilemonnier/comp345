#include <iostream>
using namespace std;

class Base
{
public:
	virtual ~Base(){
		cout << "Base::~Base()" << endl;
	}
};

class Derived : public Base
{
public:
	~Derived(){
		cout << "Derived::~Derived()" << endl;
		// Do some important cleanup
	}
};

int main(){
	Base *b = new Derived();
	// use b
	delete b; // Here's the problem!
	int i; cin >> i;
}