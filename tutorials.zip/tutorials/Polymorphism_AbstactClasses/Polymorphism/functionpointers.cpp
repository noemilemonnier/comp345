#include <iostream>
using namespace std;

float Plus(float a, float b)     {return a + b;}
float Minus(float a, float b)    {return a - b;}
float Multiply(float a, float b) {return a * b;}
float Divide(float a, float b)   {return a / b;}

float Switch(float a, float b, char opCode) {
	float result; // execute operation 
	switch (opCode) {
	case '+': result = Plus(a, b); break;
	case '-': result = Minus(a, b); break;
	case '*': result = Multiply(a, b); break;
	case '/': result = Divide(a, b); break;
	}
	return result;
}

float Switch_With_Function_Pointer(float a, float b,
	float(*ptFunc)(float, float)) {
	// call using function pointer 
	float result = ptFunc(a, b); 
	return result;
}  

int main(){
	//function pointer declaration
	float(*op)(float, float);
	//assign the address of a particular function 
	op = &Plus;
	cout << "Switch: 1+2=";
	cout << Switch(1, 2, '+') << endl;
	cout << "Switch_With_Function_Pointer: 1+2=";
	cout << Switch_With_Function_Pointer(1, 2, op) << endl;
	int i; cin >> i;
}


