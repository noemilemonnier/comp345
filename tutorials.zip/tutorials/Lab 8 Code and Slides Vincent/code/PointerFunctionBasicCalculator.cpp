/*
Code example from learncpp
*/

#include "stdafx.h"
/**
#include <iostream>

//this function takes user input of integers
int getInteger()
{
	std::cout << "Enter an integer: ";
	int x;
	std::cin >> x;
	return x;
}

//this function determines what type of arithmetic operation user wants from their input
char getOperation()
{
	char op;

	do
	{
		std::cout << "Enter an operation ('+', '-', '*', '/'): ";
		std::cin >> op;
	} while (op != '+' && op != '-' && op != '*' && op != '/');

	return op;
}

//function for addition
int add(int x, int y)
{
	return x + y;
}

//function for subtraction
int subtract(int x, int y)
{
	return x - y;
}

//function for multiplication
int multiply(int x, int y)
{
	return x * y;
}

//function for division
int divide(int x, int y)
{
	return x / y;
}

typedef int(*arithmeticFcn)(int, int);	//function pointer made cleaner via typedef

//struct with type of operation and arithmetic function pointer
struct arithmeticStruct
{
	char op;
	arithmeticFcn fcn;
};

//global array of struct arithmeticStruct
static const arithmeticStruct arithmeticArray[]
{
	{ '+', add },
	{ '-', subtract },
	{ '*', multiply },
	{ '/', divide }
};

//function to iterate through array to get desired arithmetic function operation
arithmeticFcn getArithmeticFcn(char op)
{
	for (const auto &arith : arithmeticArray)	//Note: auto is used here for compiler to infer the type
	{
		if (arith.op == op)
			return arith.fcn;
	}
	return add; // default will be to add
}

int main()
{
	int x = getInteger();		//get first operand
	char op = getOperation();	//get operation
	int y = getInteger();		//get second operand

	arithmeticFcn fcn = getArithmeticFcn(op);								//get desired function and store in function pointer
	std::cout << x << ' ' << op << ' ' << y << " = " << fcn(x, y) << '\n';	//output the result using function pointer

	return 0;
}
/**/