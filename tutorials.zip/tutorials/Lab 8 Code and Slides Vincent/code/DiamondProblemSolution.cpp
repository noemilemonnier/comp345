#include "stdafx.h"
/**
#include <iostream>
using std::cout;
using std::endl;

class Animal
{
public:
	Animal() { cout << "I am an animal!" << endl; }
	virtual ~Animal() { }
	virtual void eat() { cout << "I can eat!" << endl; }
};

//class Mammal : public Animal
class Mammal : virtual public Animal
{
public:
	Mammal() { cout << "I am a mammal!" << endl; }
	~Mammal() {}
	virtual void breathe() {}
};

//class WingedAnimal : public Animal
class WingedAnimal : virtual public Animal
{
public:
	WingedAnimal() { cout << "I am a winged animal!" << endl; }
	~WingedAnimal() {}
	virtual void flap() {}
};

// A bat is a winged mammal
class Bat : public Mammal, WingedAnimal 
{
public:
	Bat() { cout << "I am a bat!" << endl; }
	~Bat() {}
};

int main()
{
	/*
	//for without virtual inheritance
	Bat bat;
	bat.eat(); //ambiguous since two Animals in Bat

	Bat b;
	Animal &a = b; // error: which Animal subobject should a Bat cast into, 
			   // a Mammal::Animal or a WingedAnimal::Animal?
	
	*/

	/**
	//for with virtual inheritance
	Bat bat;

	Bat b;
	Animal &a = b;
	b.eat();

	return 0;
}
/**/