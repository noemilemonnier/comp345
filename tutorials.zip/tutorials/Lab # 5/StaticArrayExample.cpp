
#include "stdafx.h"
#include <iostream>
/*
using std::cout;
using std::endl;

#define ARRAY_SIZE 4 //another way to define a constant using preprocessor

void printArrayContents(int n[], int size)
{
	cout << "Printing contents of array: ";
	for (int i = 0; i < size; i++) //could make it ARRAY_SIZE here
	{
		cout << n[i] << " ";
	}
	cout << endl;
}

void changingArrayContents(int n[], int size)
{
	for (int i = 0; i < size; i++)
	{
		n[i] = 1;
	}
}

int main()
{
	//constant size 
	const int MAX_SIZE = 3;

	//declare and initialize int static array without constant
	int scores1[3];
	scores1[0] = 100;
	scores1[1] = 90;
	scores1[2] = 80;
	printArrayContents(scores1, 3);

	//alternate way
	int scores2[] = {95, 55}; //size is optional in the [], since compiler gets it from elements in {}
	printArrayContents(scores2, 2);

	//with constant
	int scores3[MAX_SIZE] = {0, 0, 0}; 
	//int scores3[MAX_SIZE] = {0, 0, 0, 0, 0}; //compiler complains unless change value of MAX_SIZE to have 5 values
	printArrayContents(scores3, MAX_SIZE);

	//with preprocessor
	int scores4[ARRAY_SIZE] = {0, 0, 0, 0};
	//int scores4[ARRAY_SIZE] = {0, 0, 0, 0, 0}; //compiler complains
	printArrayContents(scores4, ARRAY_SIZE);

	//with missing values
	int scores5[5] = { 100, 100, 100 }; //remaining ones will be default, so 0!!
	printArrayContents(scores5, 5);

	//to show that actually changing contents of array
	int a[3] = {0, 0, 0}; 
	changingArrayContents(a, 3);

	cout << "Array contents of a[]: ";
	for (int i = 0; i < 3; i++)
	{
		cout << a[i] << " ";
	}
	cout << endl;
	
	return 0;
}
/**/