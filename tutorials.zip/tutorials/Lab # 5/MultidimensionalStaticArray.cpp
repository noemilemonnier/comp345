
#include "stdafx.h"
#include <iostream>
/*
using std::cout;
using std::endl;

void printArrayContents(int n[][3], int size)
{
	cout << "Printing contents of array: " << endl;
	for (int i = 0; i < size; i++) //row
	{
		for (int j = 0; j < 3; j++) //column
		{
			cout << n[i][j] << " ";
		}
		cout << endl;
	}
	cout << endl;
}

int main()
{
	//declare and initialize multidimensional static array 3 x 3
	int a[][3] = { {1, 2, 3}, {4, 5, 6}, {7, 8, 9} };
	//int a[3][3] = { {1, 2, 3}, {4, 5, 6}, {7, 8, 9} }; //also good
	//int a[][] = { {1, 2, 3}, {4, 5, 6}, {7, 8, 9} }; //compiler complains
	
	cout << "Printing content at a[1][2]: " << a[1][2] << "\n" << endl; //should be 6

	printArrayContents(a, 3);

	cout << "\nPrint a[1][0] using pointer arithmetic *(*(a+1)+0): " << *(*(a+1)+0) << endl; //should be 4
	cout << "\nPrint a[1][0] using pointer arithmetic *(*(a+0)+3): " << *(*(a+0)+3) << endl; //should be 4

	return 0;
}
/**/