
#include "stdafx.h"
#include <iostream>
/*
using std::cout;
using std::endl;

void printArrayContents(int** n, int size1, int size2)
{
	cout << "Printing contents of array: " << endl;
	for (int i = 0; i < size1; i++) //row
	{
		for (int j = 0; j < size2; j++) //column
		{
			cout << n[i][j] << " ";
		}
		cout << endl;
	}
	cout << endl;
}

int main()
{
	//declare and initialize multidimensional dynamic array
	int** a = new int*[3]; //outer array and its size

	//inner array and its size
	for (int i = 0; i < 3; i++)
		a[i] = new int[3](); //initialize all of them to 0

	printArrayContents(a, 3, 3);

	//deallocation
	for (int i = 0; i < 3; i++)
	{
		delete[] a[i]; //deleting the inner arrays
		a[i] = NULL;
	}
	delete[] a; //deleting outer array
	a = NULL;

	return 0;
}
/**/