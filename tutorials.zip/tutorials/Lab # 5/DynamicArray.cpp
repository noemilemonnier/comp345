
#include "stdafx.h"
#include <iostream>
/*
using std::cout;
using std::endl;

void printArrayContents(int* n, int size)
{
	cout << "Printing contents of array: ";
	for (int i = 0; i < size; i++)
	{
		cout << n[i] << " ";
	}
	cout << endl;
}

int main()
{
	//declare and initialize dynamic array
	int *a = new int[3];  //Note: remember it can be int* too!
	a[0] = 1;
	a[1] = 2;
	a[2] = 3;

	int* b = new int[4];
	for (int i = 0; i < 4; i++)
		b[i] = 1 + i;

	printArrayContents(a, 3);
	printArrayContents(b, 4);

	//changing size of a
	int* c = new int[6](); //Calls on default constructor of int object, so will make {0, 0, 0, 0, 0, 0}
	for (int i = 0; i < 3; i++)
		c[i] = a[i];
	delete[] a;
	a = c;

	printArrayContents(a, 6);
	delete[] a; //also deletes c since pointing to same dynamic array
	a = NULL; //c also becomes null
	delete[] b;
	b = NULL;
	return 0;
}
/**/